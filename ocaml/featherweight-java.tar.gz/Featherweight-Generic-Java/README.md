Featherweight-Generic-Java
==========================

Featherweight Generic Java interpreter and type system and "dynamic" type safety all implemented in OCaml

Benjamin Pierce's lexer/parser has been modified for the purposes of FGJ.
