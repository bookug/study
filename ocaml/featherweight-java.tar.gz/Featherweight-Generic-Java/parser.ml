type token =
  | LAMBDA of (Support.Error.info)
  | IF of (Support.Error.info)
  | THEN of (Support.Error.info)
  | ELSE of (Support.Error.info)
  | TRUE of (Support.Error.info)
  | FALSE of (Support.Error.info)
  | BOOL of (Support.Error.info)
  | LET of (Support.Error.info)
  | FOR of (Support.Error.info)
  | IN of (Support.Error.info)
  | EMPTY of (Support.Error.info)
  | UNIT of (Support.Error.info)
  | FLOAT of (Support.Error.info)
  | INT of (Support.Error.info)
  | OBJECT of (Support.Error.info)
  | CLASS of (Support.Error.info)
  | THIS of (Support.Error.info)
  | RETURN of (Support.Error.info)
  | NEW of (Support.Error.info)
  | EXTENDS of (Support.Error.info)
  | SUPER of (Support.Error.info)
  | TTOP of (Support.Error.info)
  | TBOT of (Support.Error.info)
  | TBOOL of (Support.Error.info)
  | TTRUE of (Support.Error.info)
  | TFALSE of (Support.Error.info)
  | TRECORD of (Support.Error.info)
  | TBASE of (Support.Error.info)
  | TLANG of (Support.Error.info)
  | TLABEL of (Support.Error.info)
  | UCID of (string Support.Error.withinfo)
  | LCID of (string Support.Error.withinfo)
  | TCID of (string Support.Error.withinfo)
  | BCID of (string Support.Error.withinfo)
  | INTV of (int Support.Error.withinfo)
  | FLOATV of (float Support.Error.withinfo)
  | STRINGV of (string Support.Error.withinfo)
  | APOSTROPHE of (Support.Error.info)
  | DQUOTE of (Support.Error.info)
  | ARROW of (Support.Error.info)
  | BANG of (Support.Error.info)
  | BARGT of (Support.Error.info)
  | BARRCURLY of (Support.Error.info)
  | BARRSQUARE of (Support.Error.info)
  | COLON of (Support.Error.info)
  | COLONCOLON of (Support.Error.info)
  | COLONEQ of (Support.Error.info)
  | COLONHASH of (Support.Error.info)
  | COMMA of (Support.Error.info)
  | DARROW of (Support.Error.info)
  | DDARROW of (Support.Error.info)
  | DOT of (Support.Error.info)
  | EOF of (Support.Error.info)
  | EQ of (Support.Error.info)
  | EQEQ of (Support.Error.info)
  | EXISTS of (Support.Error.info)
  | GT of (Support.Error.info)
  | HASH of (Support.Error.info)
  | LCURLY of (Support.Error.info)
  | LCURLYBAR of (Support.Error.info)
  | LEFTARROW of (Support.Error.info)
  | LPAREN of (Support.Error.info)
  | LSQUARE of (Support.Error.info)
  | LSQUAREBAR of (Support.Error.info)
  | LT of (Support.Error.info)
  | RCURLY of (Support.Error.info)
  | RPAREN of (Support.Error.info)
  | RSQUARE of (Support.Error.info)
  | SEMI of (Support.Error.info)
  | SLASH of (Support.Error.info)
  | STAR of (Support.Error.info)
  | PLUS of (Support.Error.info)
  | TRIANGLE of (Support.Error.info)
  | USCORE of (Support.Error.info)
  | VBAR of (Support.Error.info)
  | SEMISEMI of (Support.Error.info)

open Parsing;;
let _ = parse_error;;
# 7 "parser.mly"
open Support.Error
open Support.Pervasive
open Syntax
# 86 "parser.ml"
let yytransl_const = [|
    0|]

let yytransl_block = [|
  257 (* LAMBDA *);
  258 (* IF *);
  259 (* THEN *);
  260 (* ELSE *);
  261 (* TRUE *);
  262 (* FALSE *);
  263 (* BOOL *);
  264 (* LET *);
  265 (* FOR *);
  266 (* IN *);
  267 (* EMPTY *);
  268 (* UNIT *);
  269 (* FLOAT *);
  270 (* INT *);
  271 (* OBJECT *);
  272 (* CLASS *);
  273 (* THIS *);
  274 (* RETURN *);
  275 (* NEW *);
  276 (* EXTENDS *);
  277 (* SUPER *);
  278 (* TTOP *);
  279 (* TBOT *);
  280 (* TBOOL *);
  281 (* TTRUE *);
  282 (* TFALSE *);
  283 (* TRECORD *);
  284 (* TBASE *);
  285 (* TLANG *);
  286 (* TLABEL *);
  287 (* UCID *);
  288 (* LCID *);
  289 (* TCID *);
  290 (* BCID *);
  291 (* INTV *);
  292 (* FLOATV *);
  293 (* STRINGV *);
  294 (* APOSTROPHE *);
  295 (* DQUOTE *);
  296 (* ARROW *);
  297 (* BANG *);
  298 (* BARGT *);
  299 (* BARRCURLY *);
  300 (* BARRSQUARE *);
  301 (* COLON *);
  302 (* COLONCOLON *);
  303 (* COLONEQ *);
  304 (* COLONHASH *);
  305 (* COMMA *);
  306 (* DARROW *);
  307 (* DDARROW *);
  308 (* DOT *);
    0 (* EOF *);
  309 (* EQ *);
  310 (* EQEQ *);
  311 (* EXISTS *);
  312 (* GT *);
  313 (* HASH *);
  314 (* LCURLY *);
  315 (* LCURLYBAR *);
  316 (* LEFTARROW *);
  317 (* LPAREN *);
  318 (* LSQUARE *);
  319 (* LSQUAREBAR *);
  320 (* LT *);
  321 (* RCURLY *);
  322 (* RPAREN *);
  323 (* RSQUARE *);
  324 (* SEMI *);
  325 (* SLASH *);
  326 (* STAR *);
  327 (* PLUS *);
  328 (* TRIANGLE *);
  329 (* USCORE *);
  330 (* VBAR *);
  331 (* SEMISEMI *);
    0|]

let yylhs = "\255\255\
\001\000\003\000\003\000\002\000\002\000\005\000\005\000\008\000\
\008\000\006\000\006\000\009\000\009\000\010\000\010\000\011\000\
\011\000\011\000\007\000\007\000\007\000\012\000\012\000\012\000\
\013\000\013\000\013\000\014\000\014\000\004\000\004\000\004\000\
\015\000\015\000\015\000\000\000"

let yylen = "\002\000\
\003\000\002\000\003\000\000\000\010\000\000\000\003\000\003\000\
\005\000\001\000\002\000\000\000\003\000\001\000\003\000\000\000\
\002\000\004\000\000\000\012\000\004\000\000\000\003\000\005\000\
\000\000\001\000\003\000\000\000\003\000\001\000\004\000\005\000\
\003\000\001\000\001\000\002\000"

let yydefred = "\000\000\
\000\000\000\000\000\000\036\000\000\000\000\000\034\000\000\000\
\035\000\000\000\000\000\000\000\000\000\000\000\000\000\010\000\
\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\
\000\000\000\000\011\000\000\000\033\000\003\000\000\000\000\000\
\007\000\000\000\000\000\000\000\000\000\000\000\000\000\031\000\
\000\000\000\000\000\000\013\000\000\000\032\000\000\000\000\000\
\000\000\000\000\000\000\015\000\000\000\000\000\029\000\009\000\
\000\000\000\000\000\000\027\000\000\000\000\000\000\000\024\000\
\000\000\000\000\021\000\005\000\000\000\000\000\000\000\000\000\
\018\000\000\000\000\000\000\000\000\000\000\000\020\000"

let yydgoto = "\002\000\
\004\000\005\000\011\000\012\000\015\000\050\000\051\000\024\000\
\027\000\036\000\066\000\038\000\048\000\040\000\013\000"

let yysindex = "\003\000\
\253\254\000\000\235\254\000\000\240\254\206\254\000\000\250\254\
\000\000\240\254\017\000\211\254\243\254\252\254\254\254\000\000\
\232\254\236\254\233\254\000\000\240\254\010\255\026\255\247\254\
\250\254\250\254\000\000\016\255\000\000\000\000\244\254\250\254\
\000\000\249\254\003\255\000\255\001\255\248\254\240\254\000\000\
\004\255\250\254\250\254\000\000\240\254\000\000\008\255\251\254\
\252\254\027\255\002\255\000\000\011\255\240\254\000\000\000\000\
\200\254\005\255\016\255\000\000\250\254\250\254\253\254\000\000\
\030\255\006\255\000\000\000\000\014\255\012\255\250\254\048\255\
\000\000\240\254\007\255\009\255\013\255\250\254\000\000"

let yyrindex = "\000\000\
\245\254\000\000\000\000\000\000\000\000\049\255\000\000\000\000\
\000\000\000\000\000\000\000\000\218\254\000\000\000\000\000\000\
\231\254\000\000\000\000\000\000\068\000\000\000\000\000\000\000\
\000\000\000\000\000\000\017\255\000\000\000\000\222\254\000\000\
\000\000\000\000\015\255\000\000\000\000\000\000\018\255\000\000\
\020\255\021\255\000\000\000\000\000\000\000\000\019\255\000\000\
\000\000\000\000\000\000\000\000\022\255\018\255\000\000\000\000\
\000\000\000\000\017\255\000\000\023\255\021\255\245\254\000\000\
\000\000\000\000\000\000\000\000\024\255\000\000\023\255\000\000\
\000\000\000\000\000\000\000\000\000\000\021\255\000\000"

let yygindex = "\000\000\
\000\000\014\000\057\000\246\255\000\000\250\255\216\255\030\000\
\000\000\037\000\011\000\028\000\038\000\000\000\000\000"

let yytablesize = 92
let yytable = "\019\000\
\007\000\018\000\008\000\001\000\061\000\004\000\012\000\004\000\
\016\000\006\000\030\000\062\000\003\000\014\000\028\000\009\000\
\020\000\025\000\034\000\035\000\004\000\067\000\021\000\012\000\
\017\000\041\000\023\000\030\000\047\000\030\000\012\000\028\000\
\012\000\028\000\053\000\012\000\035\000\079\000\022\000\026\000\
\028\000\031\000\029\000\047\000\010\000\032\000\033\000\037\000\
\039\000\004\000\042\000\043\000\049\000\045\000\065\000\044\000\
\054\000\046\000\057\000\059\000\055\000\069\000\071\000\075\000\
\065\000\074\000\058\000\002\000\006\000\072\000\014\000\070\000\
\063\000\077\000\076\000\008\000\068\000\030\000\056\000\052\000\
\078\000\073\000\022\000\025\000\026\000\019\000\064\000\023\000\
\016\000\017\000\000\000\060\000"

let yycheck = "\010\000\
\017\001\008\000\019\001\001\000\061\001\017\001\032\001\019\001\
\015\001\031\001\049\001\068\001\016\001\064\001\049\001\032\001\
\000\000\020\001\025\000\026\000\032\001\062\000\068\001\049\001\
\031\001\032\000\031\001\066\001\039\000\068\001\056\001\066\001\
\058\001\068\001\045\000\061\001\043\000\078\000\052\001\064\001\
\061\001\032\001\066\001\054\000\061\001\020\001\056\001\032\001\
\061\001\061\001\058\001\049\001\049\001\053\001\061\000\056\001\
\049\001\066\001\032\001\049\001\066\001\032\001\049\001\074\000\
\071\000\018\001\065\001\000\000\020\001\058\001\056\001\066\001\
\068\001\065\001\068\001\056\001\063\000\021\000\049\000\043\000\
\068\001\071\000\066\001\066\001\066\001\065\001\059\000\066\001\
\066\001\066\001\255\255\054\000"

let yynames_const = "\
  "

let yynames_block = "\
  LAMBDA\000\
  IF\000\
  THEN\000\
  ELSE\000\
  TRUE\000\
  FALSE\000\
  BOOL\000\
  LET\000\
  FOR\000\
  IN\000\
  EMPTY\000\
  UNIT\000\
  FLOAT\000\
  INT\000\
  OBJECT\000\
  CLASS\000\
  THIS\000\
  RETURN\000\
  NEW\000\
  EXTENDS\000\
  SUPER\000\
  TTOP\000\
  TBOT\000\
  TBOOL\000\
  TTRUE\000\
  TFALSE\000\
  TRECORD\000\
  TBASE\000\
  TLANG\000\
  TLABEL\000\
  UCID\000\
  LCID\000\
  TCID\000\
  BCID\000\
  INTV\000\
  FLOATV\000\
  STRINGV\000\
  APOSTROPHE\000\
  DQUOTE\000\
  ARROW\000\
  BANG\000\
  BARGT\000\
  BARRCURLY\000\
  BARRSQUARE\000\
  COLON\000\
  COLONCOLON\000\
  COLONEQ\000\
  COLONHASH\000\
  COMMA\000\
  DARROW\000\
  DDARROW\000\
  DOT\000\
  EOF\000\
  EQ\000\
  EQEQ\000\
  EXISTS\000\
  GT\000\
  HASH\000\
  LCURLY\000\
  LCURLYBAR\000\
  LEFTARROW\000\
  LPAREN\000\
  LSQUARE\000\
  LSQUAREBAR\000\
  LT\000\
  RCURLY\000\
  RPAREN\000\
  RSQUARE\000\
  SEMI\000\
  SLASH\000\
  STAR\000\
  PLUS\000\
  TRIANGLE\000\
  USCORE\000\
  VBAR\000\
  SEMISEMI\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'DeclarationList) in
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'TermList) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : Support.Error.info) in
    Obj.repr(
# 138 "parser.mly"
      ( fun _ -> 
            let tvars = emptyNames in 
            (_1 tvars, _2 tvars) 
      )
# 350 "parser.ml"
               :  Syntax.names -> Syntax.prog ))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'Term) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : Support.Error.info) in
    Obj.repr(
# 145 "parser.mly"
 ( fun names -> [_1 names] )
# 358 "parser.ml"
               : 'TermList))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'Term) in
    let _2 = (Parsing.peek_val __caml_parser_env 1 : Support.Error.info) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'TermList) in
    Obj.repr(
# 147 "parser.mly"
( fun names -> (_1 names)::(_3 names) )
# 367 "parser.ml"
               : 'TermList))
; (fun __caml_parser_env ->
    Obj.repr(
# 152 "parser.mly"
      ( fun names -> [] )
# 373 "parser.ml"
               : 'DeclarationList))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 9 : Support.Error.info) in
    let _2 = (Parsing.peek_val __caml_parser_env 8 : string Support.Error.withinfo) in
    let _3 = (Parsing.peek_val __caml_parser_env 7 : 'TVarListOpt) in
    let _4 = (Parsing.peek_val __caml_parser_env 6 : Support.Error.info) in
    let _5 = (Parsing.peek_val __caml_parser_env 5 : 'AType) in
    let _6 = (Parsing.peek_val __caml_parser_env 4 : Support.Error.info) in
    let _7 = (Parsing.peek_val __caml_parser_env 3 : 'MemberList) in
    let _8 = (Parsing.peek_val __caml_parser_env 2 : Support.Error.info) in
    let _9 = (Parsing.peek_val __caml_parser_env 1 : Support.Error.info) in
    let _10 = (Parsing.peek_val __caml_parser_env 0 : 'DeclarationList) in
    Obj.repr(
# 156 "parser.mly"
      (
        fun env_tvars ->
           let name = mkname _2 in
           let (tvars, mkcons) = _3 env_tvars in
           let tycons =  
              List.map (fun mktyc -> mktyc tvars) mkcons 
           in
           let supty = _5 tvars in
           let members = _7 [] [] tvars in
           let decls = _10 env_tvars 
           in
              (DeclClass (name, tycons, supty, members)) :: decls
      )
# 401 "parser.ml"
               : 'DeclarationList))
; (fun __caml_parser_env ->
    Obj.repr(
# 172 "parser.mly"
      ( fun _ ->  (emptyNames, []) )
# 407 "parser.ml"
               : 'TVarListOpt))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : Support.Error.info) in
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'ConstraintList) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : Support.Error.info) in
    Obj.repr(
# 174 "parser.mly"
      ( fun names ->  _2 names )
# 416 "parser.ml"
               : 'TVarListOpt))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : string Support.Error.withinfo) in
    let _2 = (Parsing.peek_val __caml_parser_env 1 : Support.Error.info) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'AType) in
    Obj.repr(
# 178 "parser.mly"
   (
      fun names -> 
         let name = mkname _1 in
         let names =  addName name names in
         let mkcons names =
            (ConSubtype (name, _3 names))
         in 
            (names, mkcons::[])
   )
# 433 "parser.ml"
               : 'ConstraintList))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 4 : string Support.Error.withinfo) in
    let _2 = (Parsing.peek_val __caml_parser_env 3 : Support.Error.info) in
    let _3 = (Parsing.peek_val __caml_parser_env 2 : 'AType) in
    let _4 = (Parsing.peek_val __caml_parser_env 1 : Support.Error.info) in
    let _5 = (Parsing.peek_val __caml_parser_env 0 : 'ConstraintList) in
    Obj.repr(
# 188 "parser.mly"
   (
      fun names->
         let name = mkname _1 in
         let names =  addName name names in
         let mkcons names = (* generate names at a later time*)
            (ConSubtype (name, _3 names))
         in 
         let (names, mkconstail) = _5 names 
         in 
            (names, mkcons::mkconstail)
   )
# 454 "parser.ml"
               : 'ConstraintList))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : Support.Error.info) in
    Obj.repr(
# 205 "parser.mly"
      ( fun _ -> TyObject )
# 461 "parser.ml"
               : 'AType))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : string Support.Error.withinfo) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'InstantiationListOpt) in
    Obj.repr(
# 207 "parser.mly"
      ( fun names -> 
         let tys = _2 names in 
         let name = mkname _1 in
         let c1 = tys = [] in
         let c2 = Syntax.existsName name names in
         (*dbg "Tyvar %a (%d) ? %b c1=%b c2=%b names=%a.\n"
         Syntax.n2p name (Syntax.getNameScope name) 
         (c1 && c2) c1 c2
         Syntax.ns2p names;*)
         if c1 && c2 then
            TyVar  (Syntax.mktyvar name)
         else 
            TyName (Syntax.mktyname name tys)
      )
# 482 "parser.ml"
               : 'AType))
; (fun __caml_parser_env ->
    Obj.repr(
# 225 "parser.mly"
      ( fun _  -> [] )
# 488 "parser.ml"
               : 'InstantiationListOpt))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : Support.Error.info) in
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'InstantiationList) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : Support.Error.info) in
    Obj.repr(
# 228 "parser.mly"
      ( fun names -> _2 names )
# 497 "parser.ml"
               : 'InstantiationListOpt))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'AType) in
    Obj.repr(
# 232 "parser.mly"
   (
      fun names -> (_1 names)::[]
   )
# 506 "parser.ml"
               : 'InstantiationList))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'AType) in
    let _2 = (Parsing.peek_val __caml_parser_env 1 : Support.Error.info) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'InstantiationList) in
    Obj.repr(
# 236 "parser.mly"
   ( 
     fun names -> (_1 names)::(_3 names)
   )
# 517 "parser.ml"
               : 'InstantiationList))
; (fun __caml_parser_env ->
    Obj.repr(
# 243 "parser.mly"
      ( 
         fun _ -> 
            ([], emptyNames) 
      )
# 526 "parser.ml"
               : 'FormalArgList))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'AType) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : string Support.Error.withinfo) in
    Obj.repr(
# 248 "parser.mly"
      (
         fun names ->
            let ty = _1 names in
            let name = mkname _2 in  
            let typedArg = (name, ty) in
            let names = addName name names in
            (typedArg :: [], names)
      )
# 541 "parser.ml"
               : 'FormalArgList))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 3 : 'AType) in
    let _2 = (Parsing.peek_val __caml_parser_env 2 : string Support.Error.withinfo) in
    let _3 = (Parsing.peek_val __caml_parser_env 1 : Support.Error.info) in
    let _4 = (Parsing.peek_val __caml_parser_env 0 : 'FormalArgList) in
    Obj.repr(
# 257 "parser.mly"
      (  
         fun names ->
            let ty = _1 names in 
            let name = mkname _2 in
            let typedArg = (name, ty) in
            let names' = addName name names in
            let tail, names''  =  _4 names' in
            (typedArg :: tail, names'')
      )
# 559 "parser.ml"
               : 'FormalArgList))
; (fun __caml_parser_env ->
    Obj.repr(
# 270 "parser.mly"
      ( fun _  _ _ -> [] )
# 565 "parser.ml"
               : 'MemberList))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 11 : 'AType) in
    let _2 = (Parsing.peek_val __caml_parser_env 10 : string Support.Error.withinfo) in
    let _3 = (Parsing.peek_val __caml_parser_env 9 : Support.Error.info) in
    let _4 = (Parsing.peek_val __caml_parser_env 8 : 'FormalArgList) in
    let _5 = (Parsing.peek_val __caml_parser_env 7 : Support.Error.info) in
    let _6 = (Parsing.peek_val __caml_parser_env 6 : Support.Error.info) in
    let _7 = (Parsing.peek_val __caml_parser_env 5 : Support.Error.info) in
    let _8 = (Parsing.peek_val __caml_parser_env 4 : 'Term) in
    let _9 = (Parsing.peek_val __caml_parser_env 3 : Support.Error.info) in
    let _10 = (Parsing.peek_val __caml_parser_env 2 : Support.Error.info) in
    let _11 = (Parsing.peek_val __caml_parser_env 1 : Support.Error.info) in
    let _12 = (Parsing.peek_val __caml_parser_env 0 : 'MemberList) in
    Obj.repr(
# 272 "parser.mly"
      (  
        fun methodNames fieldNames classCtx -> 

           if List.exists (fun name -> _2.v = name) methodNames then
              error _2.i "Duplicate method declaration. No overloading is allowed.";

           let retty = _1 classCtx in
           let formals, classCtx'' = _4 classCtx in
           let tmbody = _8 classCtx'' in
           let memberTail = _12 (_2.v :: methodNames) fieldNames classCtx in
            (MemMeth (mkname _2, formals, retty, tmbody)) :: memberTail 
      )
# 594 "parser.ml"
               : 'MemberList))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 3 : 'AType) in
    let _2 = (Parsing.peek_val __caml_parser_env 2 : string Support.Error.withinfo) in
    let _3 = (Parsing.peek_val __caml_parser_env 1 : Support.Error.info) in
    let _4 = (Parsing.peek_val __caml_parser_env 0 : 'MemberList) in
    Obj.repr(
# 285 "parser.mly"
      (  
         fun methodNames fieldNames classCtx ->

           if List.exists (fun name -> _2.v = name) fieldNames then
              error _2.i "Duplicate field declaration.";
 
           let retty = _1 classCtx in
           let memberTail = _4 methodNames (_2.v :: fieldNames) classCtx in
           (MemField (mkname _2, retty)) :: memberTail 
      )
# 613 "parser.ml"
               : 'MemberList))
; (fun __caml_parser_env ->
    Obj.repr(
# 299 "parser.mly"
      ( fun _ -> [] )
# 619 "parser.ml"
               : 'InitList))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : string Support.Error.withinfo) in
    let _2 = (Parsing.peek_val __caml_parser_env 1 : Support.Error.info) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'Term) in
    Obj.repr(
# 301 "parser.mly"
      (
        fun names -> (mkname _1, _3 names)::[]
      )
# 630 "parser.ml"
               : 'InitList))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 4 : string Support.Error.withinfo) in
    let _2 = (Parsing.peek_val __caml_parser_env 3 : Support.Error.info) in
    let _3 = (Parsing.peek_val __caml_parser_env 2 : 'Term) in
    let _4 = (Parsing.peek_val __caml_parser_env 1 : Support.Error.info) in
    let _5 = (Parsing.peek_val __caml_parser_env 0 : 'InitList) in
    Obj.repr(
# 305 "parser.mly"
      ( 
        fun names ->
           let tl = _5 names in
           let exists = 
              List.exists (fun (n, _) -> _1.v = string_of_name n) tl
           in
               if exists then
                  error _1.i "Duplicate field name in named argument list."
               else
                  (mkname _1, _3 names)::tl
      )
# 651 "parser.ml"
               : 'InitList))
; (fun __caml_parser_env ->
    Obj.repr(
# 319 "parser.mly"
      ( fun _ -> [] )
# 657 "parser.ml"
               : 'ArgList))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'Term) in
    Obj.repr(
# 321 "parser.mly"
      (
         fun names -> (_1 names) :: [] 
      )
# 666 "parser.ml"
               : 'ArgList))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'Term) in
    let _2 = (Parsing.peek_val __caml_parser_env 1 : Support.Error.info) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'ArgList) in
    Obj.repr(
# 325 "parser.mly"
      (  
         fun names ->  (_1 names) :: (_3 names)
      )
# 677 "parser.ml"
               : 'ArgList))
; (fun __caml_parser_env ->
    Obj.repr(
# 331 "parser.mly"
      ( fun _ -> None )
# 683 "parser.ml"
               : 'ArgListOpt))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : Support.Error.info) in
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'ArgList) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : Support.Error.info) in
    Obj.repr(
# 333 "parser.mly"
      ( fun names -> Some (_2 names) )
# 692 "parser.ml"
               : 'ArgListOpt))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'ATerm) in
    Obj.repr(
# 337 "parser.mly"
      ( fun names -> _1 names )
# 699 "parser.ml"
               : 'Term))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 3 : 'ATerm) in
    let _2 = (Parsing.peek_val __caml_parser_env 2 : Support.Error.info) in
    let _3 = (Parsing.peek_val __caml_parser_env 1 : string Support.Error.withinfo) in
    let _4 = (Parsing.peek_val __caml_parser_env 0 : 'ArgListOpt) in
    Obj.repr(
# 339 "parser.mly"
      ( fun names ->
          let  tm = _1 names in
          let  name = mkname _3 in 
          match _4 names with
             None -> TmField(_3.i, tm, name)
           | Some(args) -> TmInvoke(_3.i, tm, name, args)
      )
# 715 "parser.ml"
               : 'Term))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 4 : Support.Error.info) in
    let _2 = (Parsing.peek_val __caml_parser_env 3 : 'AType) in
    let _3 = (Parsing.peek_val __caml_parser_env 2 : Support.Error.info) in
    let _4 = (Parsing.peek_val __caml_parser_env 1 : 'InitList) in
    let _5 = (Parsing.peek_val __caml_parser_env 0 : Support.Error.info) in
    Obj.repr(
# 347 "parser.mly"
      ( 
         fun names -> 
             let ty = _2 names in
             let names, tms = List.split (_4 names) in
                TmNew (_1, ty, names, tms)
      )
# 731 "parser.ml"
               : 'Term))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : Support.Error.info) in
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'Term) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : Support.Error.info) in
    Obj.repr(
# 357 "parser.mly"
      ( fun names -> _2 names )
# 740 "parser.ml"
               : 'ATerm))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : Support.Error.info) in
    Obj.repr(
# 359 "parser.mly"
      ( fun _ -> TmVar thisName )
# 747 "parser.ml"
               : 'ATerm))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string Support.Error.withinfo) in
    Obj.repr(
# 361 "parser.mly"
    ( fun _ -> TmVar(mkname _1) )
# 754 "parser.ml"
               : 'ATerm))
(* Entry toplevel *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
|]
let yytables =
  { Parsing.actions=yyact;
    Parsing.transl_const=yytransl_const;
    Parsing.transl_block=yytransl_block;
    Parsing.lhs=yylhs;
    Parsing.len=yylen;
    Parsing.defred=yydefred;
    Parsing.dgoto=yydgoto;
    Parsing.sindex=yysindex;
    Parsing.rindex=yyrindex;
    Parsing.gindex=yygindex;
    Parsing.tablesize=yytablesize;
    Parsing.table=yytable;
    Parsing.check=yycheck;
    Parsing.error_function=parse_error;
    Parsing.names_const=yynames_const;
    Parsing.names_block=yynames_block }
let toplevel (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 1 lexfun lexbuf :  Syntax.names -> Syntax.prog )
